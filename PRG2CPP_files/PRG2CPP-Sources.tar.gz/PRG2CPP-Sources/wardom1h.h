    void kolor(int red, int green, int blue, int alpha = 255);
