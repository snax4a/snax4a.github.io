#include <iostream>
#include <string>
using namespace std;

int main() {
    double waga = 76.5;
    int  wzrost = 182;
    string imie = "Jan";
    cout << imie   << " wazy " << waga << " kg i ma "
         << wzrost << " cm wzrostu."  << endl;
}
