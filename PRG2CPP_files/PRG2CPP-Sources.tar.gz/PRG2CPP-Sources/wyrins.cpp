#include <iostream>
#include <cstdio>
using namespace std;

int main() {
   int k = 7, m = 8;
   ++k;
   k+1;
   k = 5;
   printf("OK?");
   k > m ? ++k : --m;
   new double(3.5);
}
