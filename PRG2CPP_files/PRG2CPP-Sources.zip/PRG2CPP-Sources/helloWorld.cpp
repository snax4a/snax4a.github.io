#include <iostream>
using namespace std;

/*
    Nauke kazdego jezyka programowania
    zaczynamy zawsze od Hello, World!!!!
 */

int main() { // Komentarze jak w Javie
    cout << "Hello, World!" << endl;
}
