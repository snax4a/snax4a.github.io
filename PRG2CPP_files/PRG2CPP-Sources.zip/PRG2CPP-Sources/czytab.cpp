#include <iostream>
using namespace std;

int main() {
   char nap1[100], nap2[100];

   cout << "\nWpisz dwa napisy oddzielone bialymi znakami: ";
   cin  >>  nap1 >> nap2;
   cout << "\nNapis 1: " << nap1 << endl;
   cout <<   "Napis 2: " << nap2 << endl << endl;
}
