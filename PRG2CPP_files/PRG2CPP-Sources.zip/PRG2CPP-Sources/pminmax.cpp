#include <iostream>
using namespace std;

int main() {
    double x, y, *pmin, *pmax;
    cout << "Podaj dwie liczby: ";
    cin  >> x >> y;
    if (x < y) {
        pmin = &x; pmax = &y;
    } else {
        pmin = &y; pmax = &x;
    }
    cout << "Min = " << *pmin << endl;
    cout << "Max = " << *pmax << endl;
}
